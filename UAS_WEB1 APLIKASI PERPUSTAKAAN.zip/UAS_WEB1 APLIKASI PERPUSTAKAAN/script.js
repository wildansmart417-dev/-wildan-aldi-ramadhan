// Data transaksi (disimpan di localStorage jika tersedia)
let transactions = JSON.parse(localStorage.getItem('libraryTransactions')) || [
    { id: 1, nama: "Andi Wijaya", judulBuku: "Pemrograman Web", jumlah: 2, kategori: "Teknologi", tanggal: "2023-10-15" },
    { id: 2, nama: "Sari Dewi", judulBuku: "Sastra Indonesia", jumlah: 1, kategori: "Sastra", tanggal: "2023-10-16" },
    { id: 3, nama: "Budi Santoso", judulBuku: "Fisika Dasar", jumlah: 3, kategori: "Pendidikan", tanggal: "2023-10-17" }
];

// User credentials untuk login
const validUsers = [
    { username: 'admin', password: 'admin123', role: 'Administrator' },
    { username: 'pustakawan', password: 'pustaka2023', role: 'Pustakawan' },
    { username: 'mahasiswa', password: 'mahasiswa123', role: 'Mahasiswa' }
];

// Status login
let isLoggedIn = false;
let currentUser = null;

// ID untuk transaksi baru
let nextTransactionId = transactions.length > 0 ? Math.max(...transactions.map(t => t.id)) + 1 : 4;

// Fungsi untuk menyimpan transaksi ke localStorage
function saveTransactionsToStorage() {
    localStorage.setItem('libraryTransactions', JSON.stringify(transactions));
}

// Fungsi untuk menampilkan halaman yang dipilih
function showPage(pageId) {
    // Sembunyikan semua halaman
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    
    // Tampilkan halaman yang dipilih
    document.getElementById(pageId).classList.add('active');
    
    // Perbarui menu navigasi aktif
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('data-page') === pageId) {
            link.classList.add('active');
        }
    });
    
    // Jika halaman transaksi ditampilkan, perbarui tabel
    if (pageId === 'transaction') {
        updateTransactionsTable();
    }
    
    // Update tampilan header berdasarkan status login
    updateLoginStatus();
}

// Fungsi untuk memperbarui status login di header
function updateLoginStatus() {
    const loginLink = document.querySelector('[data-page="login"]');
    
    if (isLoggedIn && currentUser) {
        loginLink.innerHTML = `<i class="fas fa-sign-out-alt"></i> Logout (${currentUser.username})`;
        loginLink.setAttribute('data-page', 'logout');
    } else {
        loginLink.innerHTML = '<i class="fas fa-sign-in-alt"></i> Login';
        loginLink.setAttribute('data-page', 'login');
    }
}

// Fungsi untuk memperbarui tabel transaksi
function updateTransactionsTable() {
    const transactionsBody = document.getElementById('transactionsBody');
    const noTransactionsMsg = document.getElementById('noTransactions');
    
    if (transactions.length === 0) {
        noTransactionsMsg.style.display = 'block';
        transactionsBody.innerHTML = '';
        return;
    }
    
    noTransactionsMsg.style.display = 'none';
    
    // Kosongkan isi tabel
    transactionsBody.innerHTML = '';
    
    // Tambahkan setiap transaksi ke tabel
    transactions.forEach(transaction => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${transaction.nama}</td>
            <td>${transaction.judulBuku}</td>
            <td>${transaction.jumlah}</td>
            <td>${transaction.kategori}</td>
            <td>
                <button class="btn btn-danger delete-btn" data-id="${transaction.id}">
                    <i class="fas fa-trash"></i> Hapus
                </button>
            </td>
        `;
        transactionsBody.appendChild(row);
    });
    
    // Tambahkan event listener untuk tombol hapus
    document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', function() {
            const transactionId = parseInt(this.getAttribute('data-id'));
            deleteTransaction(transactionId);
        });
    });
}

// Fungsi untuk menghapus transaksi
function deleteTransaction(id) {
    if (confirm('Apakah Anda yakin ingin menghapus transaksi ini?')) {
        transactions = transactions.filter(transaction => transaction.id !== id);
        saveTransactionsToStorage();
        updateTransactionsTable();
    }
}

// Fungsi untuk validasi form transaksi
function validateTransactionForm() {
    let isValid = true;
    
    // Reset pesan error
    document.querySelectorAll('#transactionForm .error').forEach(error => {
        error.style.display = 'none';
    });
    
    // Validasi setiap field
    const nama = document.getElementById('nama');
    const judulBuku = document.getElementById('judulBuku');
    const jumlah = document.getElementById('jumlah');
    const kategori = document.getElementById('kategori');
    const tanggal = document.getElementById('tanggal');
    
    if (!nama.value.trim()) {
        document.getElementById('namaError').style.display = 'block';
        isValid = false;
    }
    
    if (!judulBuku.value.trim()) {
        document.getElementById('judulBukuError').style.display = 'block';
        isValid = false;
    }
    
    if (!jumlah.value || parseInt(jumlah.value) < 1 || parseInt(jumlah.value) > 10) {
        document.getElementById('jumlahError').style.display = 'block';
        isValid = false;
    }
    
    if (!kategori.value) {
        document.getElementById('kategoriError').style.display = 'block';
        isValid = false;
    }
    
    if (!tanggal.value) {
        document.getElementById('tanggalError').style.display = 'block';
        isValid = false;
    }
    
    return isValid;
}

// Fungsi untuk validasi form login
function validateLoginForm() {
    let isValid = true;
    
    // Reset pesan error
    document.querySelectorAll('#loginForm .error').forEach(error => {
        error.style.display = 'none';
    });
    
    // Validasi setiap field
    const username = document.getElementById('username');
    const password = document.getElementById('password');
    
    if (!username.value.trim()) {
        document.getElementById('usernameError').style.display = 'block';
        isValid = false;
    }
    
    if (!password.value.trim()) {
        document.getElementById('passwordError').style.display = 'block';
        isValid = false;
    }
    
    return isValid;
}

// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    // Inisialisasi tabel transaksi
    updateTransactionsTable();
    
    // Set tanggal hari ini sebagai default
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('tanggal').value = today;
    
    // Navigasi menu
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const pageId = this.getAttribute('data-page');
            
            // Handle logout
            if (pageId === 'logout') {
                isLoggedIn = false;
                currentUser = null;
                updateLoginStatus();
                showPage('home');
                return;
            }
            
            showPage(pageId);
        });
    });
    
    // Form transaksi submit
    document.getElementById('transactionForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (!isLoggedIn) {
            alert('Anda harus login terlebih dahulu untuk menambahkan transaksi!');
            showPage('login');
            return;
        }
        
        if (validateTransactionForm()) {
            // Ambil nilai dari form
            const nama = document.getElementById('nama').value;
            const judulBuku = document.getElementById('judulBuku').value;
            const jumlah = document.getElementById('jumlah').value;
            const kategori = document.getElementById('kategori').value;
            const tanggal = document.getElementById('tanggal').value;
            
            // Tambahkan transaksi baru
            const newTransaction = {
                id: nextTransactionId++,
                nama: nama,
                judulBuku: judulBuku,
                jumlah: parseInt(jumlah),
                kategori: kategori,
                tanggal: tanggal
            };
            
            transactions.push(newTransaction);
            saveTransactionsToStorage();
            
            // Perbarui tabel
            updateTransactionsTable();
            
            // Reset form
            this.reset();
            document.getElementById('tanggal').value = today;
            
            // Tampilkan pesan sukses
            alert('Transaksi berhasil disimpan!');
        }
    });
    
    // Tombol lihat daftar transaksi
    document.getElementById('viewTransactionsBtn').addEventListener('click', function(e) {
        e.preventDefault();
        // Scroll ke tabel transaksi
        document.querySelector('.table-section').scrollIntoView({ behavior: 'smooth' });
    });
    
    // Form login submit
    document.getElementById('loginForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (validateLoginForm()) {
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            
            // Cek kredensial pengguna
            const user = validUsers.find(u => u.username === username && u.password === password);
            
            if (user) {
                isLoggedIn = true;
                currentUser = user;
                
                alert(`Login berhasil! Selamat datang, ${user.role} ${user.username}`);
                
                // Reset form
                this.reset();
                
                // Update tampilan header
                updateLoginStatus();
                
                // Arahkan ke halaman beranda
                showPage('home');
            } else {
                alert('Username atau password salah! Silakan coba lagi.');
            }
        }
    });
    
    // Link register
    document.getElementById('registerLink').addEventListener('click', function(e) {
        e.preventDefault();
        alert('Fitur pendaftaran akan segera tersedia! Untuk saat ini, gunakan salah satu akun berikut:\n\n' +
              '1. Username: admin, Password: admin123\n' +
              '2. Username: pustakawan, Password: pustaka2023\n' +
              '3. Username: mahasiswa, Password: mahasiswa123');
    });
    
    // Cek apakah sudah login sebelumnya (dari localStorage)
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
        const user = JSON.parse(savedUser);
        const validUser = validUsers.find(u => u.username === user.username && u.password === user.password);
        
        if (validUser) {
            isLoggedIn = true;
            currentUser = validUser;
            updateLoginStatus();
        }
    }
    
    // Simpan user ke localStorage saat login
    window.addEventListener('beforeunload', function() {
        if (currentUser) {
            localStorage.setItem('currentUser', JSON.stringify({
                username: currentUser.username,
                password: currentUser.password
            }));
        } else {
            localStorage.removeItem('currentUser');
        }
    });
});